# Ansible Collection - bap_coe.gcp_management

This collection contains scripts to manage administrative tasks on GCP.