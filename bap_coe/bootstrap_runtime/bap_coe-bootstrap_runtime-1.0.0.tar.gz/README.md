# Ansible Collection - bap_coe.bootstrap_runtime

The purpose of this collection it to provide you with a rapid mechanism
for bootstrapping a workspace. There are two goals. First goal is to 
minimize the time required to configure a runtime environment. The second
goal is to make it easy to do the right thing and use a virtual environment
to isolate the script runtime from the system runtime and thus enhance
security. 


